#ifndef _minimize_h_INCLUDED
#define _minimize_h_INCLUDED

struct kissat;

void kissat_minimize_clause(struct kissat *);

#endif
