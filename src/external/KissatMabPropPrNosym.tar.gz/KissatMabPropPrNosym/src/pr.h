#ifndef _pr_h_INCLUDED
#define _pr_h_INCLUDED

struct kissat;

int kissat_pr_search(struct kissat *);


#endif
