#!/bin/sh
"$(dirname "$0")/ganak" "$@" | grep -v ^s |  sed 's/c s exact arb int/s/'