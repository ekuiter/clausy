Array3d v(3,2,4), w(5,4,2);
v /= w;
cout << v << endl;
