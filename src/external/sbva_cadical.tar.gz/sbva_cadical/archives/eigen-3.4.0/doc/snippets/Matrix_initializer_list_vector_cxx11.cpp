VectorXi v {{1, 2}};
cout << v << endl;
